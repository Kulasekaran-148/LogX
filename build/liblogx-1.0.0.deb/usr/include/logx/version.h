#ifndef _VERSION_H
#define _VERSION_H

#define LOGX_MAJOR_VERSION 1
#define LOGX_MINOR_VERSION 0
#define LOGX_PATCH_VERSION 0

#endif